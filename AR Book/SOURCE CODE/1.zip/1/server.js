const express = require('express');
const cors = require('cors');
const multer = require('multer');
const mongoose = require('mongoose');
const { GridFSBucket } = require('mongodb');
const PDFJS = require('pdfjs-dist/legacy/build/pdf.js');
const axios = require('axios');
const stream = require('stream');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const fs = require('fs');
const FormData = require('form-data');

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection URI - replace with your own or env variable for production
const mongoURI = 'mongodb://127.0.0.1:27017/bookar_db';

// Connect to MongoDB
mongoose.connect(mongoURI);

const conn = mongoose.connection;

let gfs;

conn.once('open', () => {
  gfs = new GridFSBucket(conn.db, {
    bucketName: 'uploads',
  });
  console.log('MongoDB connected, GridFSBucket initialized');
});

// Multer Setup for memory storage so we can directly pipe buffer to GridFS
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Schemas

const BookSchema = new mongoose.Schema({
  title: { type: String, required: false },
  pdfFileId: { type: mongoose.Schema.Types.ObjectId, required: true },
  pageCount: { type: Number, required: true },
  connectedWebpage: { type: String, required: false }, // <-- add this line
});

const ARContentSchema = new mongoose.Schema({
  bookId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'Book' },
  pageNumber: { type: Number, required: true },
  contentType: { type: String, enum: ['image', 'video', 'audio', 'model3d'], required: true },
  fileId: { type: mongoose.Schema.Types.ObjectId, required: true }, // GridFS file id
  filename: { type: String, required: true },
  uploadedAt: { type: Date, default: Date.now },
});

const Book = mongoose.model('Book', BookSchema);
const ARContent = mongoose.model('ARContent', ARContentSchema);

// Utility: get PDF page count from buffer using pdfjs-dist
async function getPdfPageCount(buffer) {
  // Convert Buffer to Uint8Array for pdfjs-dist
  const uint8array = new Uint8Array(buffer);
  const loadingTask = PDFJS.getDocument({ data: uint8array });
  const pdf = await loadingTask.promise;
  return pdf.numPages;
}

// POST /upload-pdf - Upload a PDF and save it in GridFS
app.post('/upload-pdf', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No PDF file uploaded' });

    const pdfBuffer = req.file.buffer;
    const pageCount = await getPdfPageCount(pdfBuffer);

    // Save file to GridFS
    const uploadStream = gfs.openUploadStream(req.file.originalname, {
      contentType: req.file.mimetype,
    });
    const bufferStream = new stream.PassThrough();
    bufferStream.end(pdfBuffer);
    bufferStream.pipe(uploadStream);

    uploadStream.on('error', (err) => {
      console.error('Error uploading PDF to GridFS:', err);
      res.status(500).json({ error: 'Error uploading PDF' });
    });

    uploadStream.on('finish', async () => {
      const pdfFileId = uploadStream.id;

      // Save book metadata
      const book = new Book({
        title: req.file.originalname,
        pdfFileId,
        pageCount,
      });
      await book.save();

      res.json({
        bookId: book._id,
        title: book.title,
        pageCount,
      });
    });
  } catch (error) {
    console.error('Upload PDF error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /book/:bookId/pages - Return page count and AR content mappings
app.get('/book/:bookId/pages', async (req, res) => {
  try {
    const bookId = req.params.bookId;
    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    const arContents = await ARContent.find({ bookId }).lean();
    const mappings = {};
    arContents.forEach((content) => {
      if (!mappings[content.pageNumber]) mappings[content.pageNumber] = [];
      mappings[content.pageNumber].push(content);
    });

    res.json({
      pageCount: book.pageCount,
      mappings,
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /upload-ar-content - upload AR content file mapped to book page
app.post('/upload-ar-content', upload.single('arFile'), async (req, res) => {
  try {
    const { bookId, pageNumber, contentType } = req.body;

    if (!req.file) return res.status(400).json({ error: 'No AR content file uploaded' });
    if (!bookId || !pageNumber || !contentType) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Save AR content file to GridFS
    const uploadStream = gfs.openUploadStream(req.file.originalname, {
      contentType: req.file.mimetype,
    });
    const bufferStream = new stream.PassThrough();
    bufferStream.end(req.file.buffer);
    bufferStream.pipe(uploadStream);

    uploadStream.on('error', (err) => {
      console.error('Error uploading AR content to GridFS:', err);
      res.status(500).json({ error: 'Error uploading AR content' });
    });

    uploadStream.on('finish', async () => {
      const fileId = uploadStream.id;

      const arContent = new ARContent({
        bookId,
        pageNumber: parseInt(pageNumber, 10),
        contentType,
        fileId,
        filename: req.file.originalname,
      });
      await arContent.save();

      res.json({
        message: 'AR content uploaded',
        arContent,
      });
    });
  } catch (error) {
    console.error('Upload AR content error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /file/:id - serve file from GridFS by id
app.get('/file/:id', async (req, res) => {
  try {
    const fileId = new mongoose.Types.ObjectId(req.params.id);
    const files = await conn.db.collection('uploads.files').find({ _id: fileId }).toArray();
    if (!files || files.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }
    const file = files[0];

    res.set('Content-Type', file.contentType);
    const downloadStream = gfs.openDownloadStream(fileId);

    downloadStream.pipe(res).on('error', () => {
      res.sendStatus(404);
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});


// Add this function for Cohere summarization
async function summarizeWithCohere(text) {
  const COHERE_API_KEY = 'Q6BGW9KB61cntUye4hKewVHvwcQiTyeXkVWCqd63'; // <-- Replace with your Cohere API key
  const response = await axios.post(
    'https://api.cohere.ai/v1/summarize',
    { text },
    {
      headers: {
        'Authorization': `Bearer ${COHERE_API_KEY}`,
        'Content-Type': 'application/json'
      }
    }
  );
  return response.data.summary;
}

// POST /summarize - summarize whole book or specific page
app.post('/summarize', async (req, res) => {
  try {
    const { bookId, pageNumber } = req.body;

    if (!bookId) return res.status(400).json({ error: 'Missing bookId' });

    // Retrieve book
    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    // Retrieve PDF file from GridFS
    const downloadStream = gfs.openDownloadStream(book.pdfFileId);

    const chunks = [];
    downloadStream.on('data', (chunk) => chunks.push(chunk));
    downloadStream.on('error', () => {
      res.status(500).json({ error: 'Error reading PDF file' });
    });
    downloadStream.on('end', async () => {
      const pdfBuffer = Buffer.concat(chunks);

      const uint8array = new Uint8Array(pdfBuffer); // <-- FIX
      const loadingTask = PDFJS.getDocument({ data: uint8array }); // <-- FIX
      const pdf = await loadingTask.promise;

      let textToSummarize = '';

      if (pageNumber) {
        const pageNum = parseInt(pageNumber, 10);
        if (pageNum < 1 || pageNum > pdf.numPages) {
          return res.status(400).json({ error: 'Invalid page number' });
        }
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        textToSummarize = textContent.items.map((i) => i.str).join(' ');
      } else {
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          textToSummarize += textContent.items.map((i) => i.str).join(' ') + '\n';
        }
      }

      // Call Cohere API for summarization
      try {
        const summary = await summarizeWithCohere(textToSummarize);
        res.json({ summary });
      } catch (err) {
        console.error('Cohere summarization error:', err.response?.data || err.message || err);
        res.status(500).json({ error: 'Failed to summarize' });
      }
    });
  } catch (error) {
    console.error('Summarize error:', error.response?.data || error.message || error);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /generate-ar-content - generate AR image from prompt (or from summary) and map to page
app.post('/generate-ar-content', async (req, res) => {
  try {
    const { prompt, bookId, pageNumber } = req.body;
    if (!prompt) return res.status(400).json({ error: 'Missing prompt' });

    const STABILITY_API_URL = 'https://api.stability.ai/v2beta/stable-image/generate/core';
    const STABILITY_API_KEY = 'sk-mkLwnGrapQ6A4gUshIrEVNXGgLJHPE2jgnsFpUHfWLAJ3B1H';

    const payload = {
      prompt,
      output_format: "png"
    };

    const form = new FormData();
    for (const key in payload) {
      form.append(key, payload[key]);
    }

    const response = await axios.post(
      STABILITY_API_URL,
      form,
      {
        responseType: "arraybuffer",
        headers: {
          ...form.getHeaders(),
          Authorization: `Bearer ${STABILITY_API_KEY}`,
          Accept: "image/*"
        },
        timeout: 60000,
      }
    );

    if (response.status === 200) {
      const imageBuffer = Buffer.from(response.data);
      let fileId = null;

      // If bookId and pageNumber are provided, save to GridFS and map as AR content
      if (bookId && pageNumber) {
        const uploadStream = gfs.openUploadStream(`generated_ar_image_${Date.now()}.png`, {
          contentType: 'image/png',
        });
        const bufferStream = new stream.PassThrough();
        bufferStream.end(imageBuffer);
        bufferStream.pipe(uploadStream);

        uploadStream.on('error', (err) => {
          console.error('Error uploading generated AR image to GridFS:', err);
          res.status(500).json({ error: 'Error uploading AR image' });
        });

        uploadStream.on('finish', async () => {
          fileId = uploadStream.id;
          // Save ARContent mapping
          const arContent = new ARContent({
            bookId,
            pageNumber: parseInt(pageNumber, 10),
            contentType: 'image',
            fileId,
            filename: uploadStream.filename,
          });
          await arContent.save();

          // Return image and ARContent info
          res.json({ 
            imageBase64: imageBuffer.toString('base64'),
            arContent
          });
        });
      } else {
        // Just return the image
        res.json({ imageBase64: imageBuffer.toString('base64') });
      }
    } else {
      throw new Error(`${response.status}: ${response.data.toString()}`);
    }
  } catch (error) {
    console.error('Generate AR content error:', error.message);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

// POST /generate-ar-video - generate AR video from prompt using JSON2Video
app.post('/generate-ar-video', async (req, res) => {
  try {
    const { prompt, bookId, pageNumber } = req.body;
    if (!prompt) return res.status(400).json({ error: 'Missing prompt' });

    const JSON2VIDEO_API_KEY = "A0GfyBfyncpt3gnX4pTOGiIXJidjfbrmgeZlfv6o"; // <-- Replace with your JSON2Video API key
    const JSON2VIDEO_API_URL = "https://api.json2video.com/v1/movie/render";

    // Build the movie JSON as per JSON2Video docs
    const moviePayload = {
      api_key: JSON2VIDEO_API_KEY,
      resolution: "full-hd",
      quality: "high",
      scenes: [
        {
          background_color: "#4392F1",
          elements: [
            {
              type: "text",
              text: prompt,
              duration: 10
            }
          ]
        }
      ]
    };

    // Step 1: Request video generation
    const response = await axios.post(
      JSON2VIDEO_API_URL,
      moviePayload,
      {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 180000,
      }
    );

    // Handle JSON2Video's response (should return a video URL or task ID)
    let videoUrl = null;
    if (response.data && response.data.video_url) {
      videoUrl = response.data.video_url;
    } else if (response.data && response.data.task_id) {
      // If JSON2Video returns a task_id, poll for completion
      const taskId = response.data.task_id;
      let status = "pending";
      let pollCount = 0;
      while (status !== "completed" && pollCount < 30) {
        await new Promise(r => setTimeout(r, 5000)); // Wait 5 seconds
        const pollRes = await axios.get(
          `https://api.json2video.com/v1/movie/status/${taskId}`,
          {
            headers: {
              'Content-Type': 'application/json'
            }
          }
        );
        status = pollRes.data?.status;
        if (status === "completed" && pollRes.data.video_url) {
          videoUrl = pollRes.data.video_url;
          break;
        }
        pollCount++;
      }
      if (!videoUrl) throw new Error("JSON2Video video generation timed out.");
    } else {
      throw new Error("JSON2Video API did not return a video URL or task ID.");
    }

    // Step 2: Download the video file from the URL
    const videoRes = await axios.get(videoUrl, { responseType: "arraybuffer" });
    const videoBuffer = Buffer.from(videoRes.data);
    let fileId = null;

    // If bookId and pageNumber are provided, save to GridFS and map as AR content
    if (bookId && pageNumber) {
      const uploadStream = gfs.openUploadStream(`generated_ar_video_${Date.now()}.mp4`, {
        contentType: 'video/mp4',
      });
      const bufferStream = new stream.PassThrough();
      bufferStream.end(videoBuffer);
      bufferStream.pipe(uploadStream);

      uploadStream.on('error', (err) => {
        console.error('Error uploading generated AR video to GridFS:', err);
        res.status(500).json({ error: 'Error uploading AR video' });
      });

      uploadStream.on('finish', async () => {
        fileId = uploadStream.id;
        // Save ARContent mapping
        const arContent = new ARContent({
          bookId,
          pageNumber: parseInt(pageNumber, 10),
          contentType: 'video',
          fileId,
          filename: uploadStream.filename,
        });
        await arContent.save();

        // Return video and ARContent info
        res.json({
          videoBase64: videoBuffer.toString('base64'),
          arContent
        });
      });
    } else {
      // Just return the video
      res.json({ videoBase64: videoBuffer.toString('base64') });
    }
  } catch (error) {
    console.error('Generate AR video error:', error.response?.data || error.message || error);
    res.status(500).json({ error: 'Server error', details: error.message || error });
  }
});

// GET /books/latest - get the most recently uploaded book
app.get('/books/latest', async (req, res) => {
  try {
    const book = await Book.findOne().sort({ _id: -1 });
    if (!book) return res.status(404).json({ error: 'No books found' });
    res.json({ bookId: book._id, title: book.title, pageCount: book.pageCount });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /book/:bookId - get book metadata
app.get('/book/:bookId', async (req, res) => {
  try {
    const book = await Book.findById(req.params.bookId);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    // Add connectedWebpage if you want to support it
    res.json({
      _id: book._id,
      title: book.title,
      pdfFileId: book.pdfFileId,
      pageCount: book.pageCount,
      connectedWebpage: book.connectedWebpage || null // optional
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
  // Do not exit the process
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`BookAR backend running on port ${PORT}`);
});