// API base URL
const API_BASE = 'http://localhost:3000';

// Elements
const pdfUpload = document.getElementById('pdf-upload');
const uploadPdfButton = document.getElementById('upload-pdf-button');
const pdfStatus = document.getElementById('pdf-status');
const pageSelect = document.getElementById('page-select');
const summaryPageSelect = document.getElementById('summary-page-select');

const arTypeSelect = document.getElementById('ar-type-select');
const arGenTypeSelect = document.getElementById('ar-gen-type-select');
const arUpload = document.getElementById('ar-upload');
const uploadArButton = document.getElementById('upload-ar-button');
const arContentList = document.getElementById('ar-content-list');

const summarizeButton = document.getElementById('summarize-button');
const summaryResult = document.getElementById('summary-result');

const arTextPrompt = document.getElementById('ar-text-prompt');
const generateArButton = document.getElementById('generate-ar-button');
const generatedArImage = document.getElementById('generated-ar-image');

const readBookButton = document.getElementById('read-book-button');

// State
let currentBookId = null;
let currentPageCount = 0;
let arContentMappings = {}; // {pageNumber: [arContent,...]}

// Enable upload PDF button when file selected
pdfUpload.addEventListener('change', () => {
  uploadPdfButton.disabled = !(pdfUpload.files.length > 0);
  pdfStatus.textContent = '';
});

// Upload PDF to backend
uploadPdfButton.addEventListener('click', async () => {
  if (!pdfUpload.files.length) return;

  uploadPdfButton.disabled = true;
  pdfStatus.style.color = 'gray';
  pdfStatus.textContent = 'Uploading PDF...';

  const formData = new FormData();
  formData.append('pdf', pdfUpload.files[0]);

  try {
    const res = await fetch(`${API_BASE}/upload-pdf`, {
      method: 'POST',
      body: formData,
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Upload failed');
    }

    const data = await res.json();
    currentBookId = data.bookId;
    currentPageCount = data.pageCount;
    pdfStatus.style.color = 'green';
    pdfStatus.textContent = `Uploaded: "${data.title}", Pages: ${data.pageCount}`;

    // Show READ BOOK button
    if (readBookButton) {
      readBookButton.style.display = 'inline-block';
      readBookButton.onclick = () => {
        window.open(`code.html?bookId=${currentBookId}`, '_blank');
      };
    }

    // Update page selectors
    updatePageSelectors(currentPageCount);

    enableMappingUI(true);

    // Fetch AR content mappings (empty initially)
    await fetchArContentMappings();

  } catch (error) {
    pdfStatus.style.color = 'red';
    pdfStatus.textContent = 'Error uploading PDF: ' + error.message;
  } finally {
    uploadPdfButton.disabled = false;
    pdfUpload.value = '';
  }
});

function updatePageSelectors(pageCount) {
  // Clear selects
  pageSelect.innerHTML = '';
  summaryPageSelect.innerHTML = '<option value="">Whole Book</option>';

  for (let i = 1; i <= pageCount; i++) {
    const option1 = document.createElement('option');
    option1.value = i;
    option1.textContent = i;
    pageSelect.appendChild(option1);

    const option2 = document.createElement('option');
    option2.value = i;
    option2.textContent = i;
    summaryPageSelect.appendChild(option2);
  }
  pageSelect.disabled = false;
  summaryPageSelect.disabled = false;
}

function enableMappingUI(enabled) {
  arTypeSelect.disabled = !enabled;
  arUpload.disabled = true;
  uploadArButton.disabled = true;

  summarizeButton.disabled = !enabled;
  arTextPrompt.disabled = !enabled;
  generateArButton.disabled = !enabled;
  arGenTypeSelect.disabled = !enabled; // Enable AI content type selector
}

// Enable AR upload input after AR content type selected
arTypeSelect.addEventListener('change', () => {
  if (arTypeSelect.value) {
    arUpload.disabled = false;
  } else {
    arUpload.disabled = true;
  }
  checkArUploadReady();
});

// Enable upload AR button only if file selected, page and type selected
arUpload.addEventListener('change', () => {
  checkArUploadReady();
});

pageSelect.addEventListener('change', () => {
  checkArUploadReady();
});

function checkArUploadReady() {
  if (
    arTypeSelect.value &&
    arUpload.files.length > 0 &&
    pageSelect.value
  ) {
    uploadArButton.disabled = false;
  } else {
    uploadArButton.disabled = true;
  }
}

// Upload AR content to backend mapped to selected page
uploadArButton.addEventListener('click', async () => {
  if (!arUpload.files.length || !currentBookId || !pageSelect.value || !arTypeSelect.value) return;
  uploadArButton.disabled = true;

  const formData = new FormData();
  formData.append('arFile', arUpload.files[0]);
  formData.append('bookId', currentBookId);
  formData.append('pageNumber', pageSelect.value);
  formData.append('contentType', arTypeSelect.value);

  try {
    const res = await fetch(`${API_BASE}/upload-ar-content`, {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Upload failed');
    }
    const data = await res.json();

    // Refresh mappings list
    await fetchArContentMappings();

    // Reset inputs
    arUpload.value = '';
    uploadArButton.disabled = true;

  } catch (error) {
    alert('Error uploading AR content: ' + error.message);
  } finally {
    uploadArButton.disabled = false;
  }
});

// Fetch AR content mappings for current book from backend
async function fetchArContentMappings() {
  if (!currentBookId) return;
  try {
    const res = await fetch(`${API_BASE}/book/${currentBookId}/pages`);
    if (!res.ok) throw new Error('Failed to fetch AR content mappings');
    const data = await res.json();
    arContentMappings = data.mappings || {};
    currentPageCount = data.pageCount || currentPageCount;

    // Refresh AR content list display
    renderArContentList();

    // Update selects if needed
    updatePageSelectors(currentPageCount);
  } catch (error) {
    console.error('Fetch AR content mappings error:', error);
  }
}

// Render the AR content mapped currently for the selected page or whole book
function renderArContentList() {
  arContentList.innerHTML = '';
  let hasContent = false;

  Object.keys(arContentMappings).forEach((pageNum) => {
    const contents = arContentMappings[pageNum];
    contents.forEach((content) => {
      hasContent = true;
      const itemDiv = document.createElement('div');
      itemDiv.classList.add('ar-content-item');

      const fileLink = document.createElement('a');
      fileLink.href = `${API_BASE}/file/${content.fileId}`;
      fileLink.target = '_blank';
      fileLink.textContent = `Page ${pageNum}: ${content.contentType.toUpperCase()} - ${content.filename}`;
      itemDiv.appendChild(fileLink);

      // Delete button (optional)
      // For now, we won't support deleting but can add later

      arContentList.appendChild(itemDiv);
    });
  });

  if (!hasContent) {
    arContentList.innerHTML = '<p style="color: gray;">No AR content mapped yet.</p>';
  }
}

// Summarize button click handler
summarizeButton.addEventListener('click', async () => {
  if (!currentBookId) return;
  summarizeButton.disabled = true;
  summaryResult.textContent = 'Summarizing...';
  generatedArImage.innerHTML = '';
  arTextPrompt.value = '';

  const pageNumber = summaryPageSelect.value || null;
  try {
    const res = await fetch(`${API_BASE}/summarize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bookId: currentBookId, pageNumber }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Summarization failed');
    }
    const data = await res.json();
    summaryResult.textContent = data.summary;

    // Automatically generate AR content from summary
    if (data.summary && data.summary.trim().length > 0) {
      arTextPrompt.value = data.summary.trim();
      await generateArContentFromPrompt(data.summary.trim());
    }

  } catch (error) {
    summaryResult.textContent = 'Error: ' + error.message;
  } finally {
    summarizeButton.disabled = false;
  }
});

// Generate AR content button click handler (manual prompt)
generateArButton.addEventListener('click', async () => {
  const prompt = arTextPrompt.value.trim();
  const genType = arGenTypeSelect.value || 'image';
  if (!prompt) return alert('Enter prompt text first');
  generateArButton.disabled = true;
  generatedArImage.innerHTML = `Generating AR ${genType}...`;
  try {
    await generateArContentFromPrompt(prompt, genType);
  } finally {
    generateArButton.disabled = false;
  }
});

// Function to generate AR content image/video from prompt and map to page
async function generateArContentFromPrompt(prompt, genType = 'image') {
  try {
    const pageNumber = summaryPageSelect.value || null;
    const body = { prompt, type: genType };
    if (currentBookId && pageNumber) {
      body.bookId = currentBookId;
      body.pageNumber = pageNumber;
    }

    let endpoint = `${API_BASE}/generate-ar-content`;
    let isVideo = false;
    if (genType === 'video') {
      endpoint = `${API_BASE}/generate-ar-video`;
      isVideo = true;
    }

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'AR content generation failed');
    }
    const data = await res.json();

    if (isVideo && data.videoBase64) {
      generatedArImage.innerHTML = `<video controls src="data:video/mp4;base64,${data.videoBase64}" style="max-width:100%;border-radius:8px;"></video>`;
      if (data.arContent) {
        await fetchArContentMappings();
      }
    } else if (data.imageBase64) {
      generatedArImage.innerHTML = `<img alt="Generated AR Content" src="data:image/png;base64,${data.imageBase64}" />`;
      if (data.arContent) {
        await fetchArContentMappings();
      }
    } else {
      generatedArImage.textContent = 'Could not generate content.';
    }
  } catch (error) {
    generatedArImage.textContent = 'Error: ' + error.message;
  }
}

// Fetch latest book on page load to enable READ BOOK button if available
window.addEventListener('DOMContentLoaded', async () => {
  try {
    const res = await fetch(`${API_BASE}/books/latest`);
    if (res.ok) {
      const data = await res.json();
      if (data.bookId) {
        currentBookId = data.bookId;
        if (readBookButton) {
          readBookButton.style.display = 'inline-block';
          readBookButton.onclick = () => {
            window.open(`code.html?bookId=${currentBookId}`, '_blank');
          };
        }
      }
    }
  } catch (e) {
    // Ignore if no book exists yet
  }
});